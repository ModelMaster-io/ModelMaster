---
name: 🎉 New Feature
about: You have implemented some neat idea that you want to make part of PHPUnit?
labels: enhancement
---

<!--
- Please target the master branch of PHPUnit.
-->
