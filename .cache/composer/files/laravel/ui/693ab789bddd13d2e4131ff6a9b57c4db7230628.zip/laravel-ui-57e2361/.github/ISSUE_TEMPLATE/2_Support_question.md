---
name: "🧐 Support Question"
about: 'This repository is only for reporting bugs or problems. If you need help, see:
  https://github.com/laravel/laravel#learning-laravel'
---

This repository is only for reporting bugs or issues. If you need support, please use the forums:

- https://laracasts.com/discuss
- https://laravel.io/forum

Alternatively, you may use Slack (https://larachat.co/), Discord (https://discordapp.com/invite/mPZNm7A), or Stack Overflow (http://stackoverflow.com/questions/tagged/laravel).

Thanks!
