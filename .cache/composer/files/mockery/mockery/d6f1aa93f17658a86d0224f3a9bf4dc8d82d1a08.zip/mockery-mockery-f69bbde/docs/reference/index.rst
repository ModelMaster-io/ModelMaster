Reference
=========

.. toctree::
    :hidden:

    creating_test_doubles
    expectations
    argument_validation
    alternative_should_receive_syntax
    spies
    partial_mocks
    protected_methods
    public_properties
    public_static_properties
    pass_by_reference_behaviours
    demeter_chains
    final_methods_classes
    magic_methods
    phpunit_integration

.. include:: map.rst.inc
