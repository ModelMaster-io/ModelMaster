---
name: "📚 Documentation Issue"
about: 'For documentation issues, open a pull request at https://github.com/laravel/docs'
---

The library documentation has its own dedicated repository. Please open a pull request at https://github.com/laravel/docs to correct the issue you have found.

Thanks!
