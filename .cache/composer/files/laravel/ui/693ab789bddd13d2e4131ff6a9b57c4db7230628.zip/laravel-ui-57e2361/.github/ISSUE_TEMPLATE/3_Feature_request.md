---
name: "💡 Feature Request"
about: 'For ideas or feature requests, please make a pull request, or open an issue'
---

If you would like to propose new library features, please make a pull request, or open an issue. Alternatively, you may message Taylor Otwell on the Laravel Discord server's #internals channel (https://discordapp.com/invite/mPZNm7A).
